#include "WProgram.h"
#include "proxySerial.h"


#if defined(__PIC32MX__)
  ProxySerial::ProxySerial(HardwareSerial * port0) {
    _proxyPort = port0; 
  }
#else if defined(__AVR_ATmega168__) || defined(__AVR_ATmega328P__) || (__AVR__)
#include "NewSoftSerial.h"
  ProxySerial::ProxySerial(NewSoftSerial * port0) {
    _proxyPort = port0; 
  }
#endif

  void ProxySerial::begin(uint16_t b) {
    _proxyPort->begin(b); 
  }

  void ProxySerial::print(int8_t i) { 
    _proxyPort->print(i); 
  }
  void ProxySerial::print(uint8_t ui) { 
    _proxyPort->print(ui); 
  };
  void ProxySerial::print(uint16_t ui) { 
    _proxyPort->print(highByte(ui)); 
    _proxyPort->print(lowByte(ui)); 
  };
  void ProxySerial::print(char c) { 
    _proxyPort->print(c); 
  };

  void ProxySerial::print(String s) { 
#if defined(__PIC32MX__)
    for (uint8_t i=0; i<s.length(); i++)         _proxyPort->print(s.charAt(i));
#else if defined(__AVR_ATmega168__) || defined(__AVR_ATmega328P__)  || (__AVR__)
    _proxyPort->print(s); 
#endif
  }

  uint8_t ProxySerial::read() { 
    return _proxyPort->read(); 
  }
  boolean ProxySerial::available() { 
    return _proxyPort->available(); 
  }
  void ProxySerial::flush() {  
    _proxyPort->flush(); 
  }





