#include "WProgram.h"
#if defined(__AVR_ATmega168__) || defined(__AVR_ATmega328P__) || defined(__AVR__)
#endif

#ifndef proxySerial_h
#define proxySerial_h

class ProxySerial
{
public:
#if defined(__PIC32MX__)
  ProxySerial(HardwareSerial * port0);
#else if defined(__AVR_ATmega168__) || defined(__AVR_ATmega328P__) || defined(__AVR__)
#include "NewSoftSerial.h"
  ProxySerial(NewSoftSerial * port0);
#endif

  void begin(uint16_t b);
  void print(int8_t i);
  void print(uint8_t ui);
  void print(uint16_t ui);
  void print(char c);
  void print(String s);
  
  uint8_t read();
  boolean available();
  void flush();

private:
#if defined(__PIC32MX__)
  HardwareSerial * _proxyPort;
#else if defined(__AVR_ATmega168__) || defined(__AVR_ATmega328P__) || (__AVR__)
  NewSoftSerial  * _proxyPort;
#endif
};

#endif

